-- Madani v2 database backup
-- Generated: 2026-09-30 08:23:21
-- Driver: sqlite

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS "activity_logs";
CREATE TABLE "activity_logs" ("id" integer primary key autoincrement not null, "user_id" integer, "action" varchar not null, "model_type" varchar, "model_id" integer, "payload" text, "created_at" datetime not null default CURRENT_TIMESTAMP, foreign key("user_id") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "attendances";
CREATE TABLE "attendances" ("id" integer primary key autoincrement not null, "schedule_id" integer not null, "student_id" integer not null, "date" date not null, "status" varchar check ("status" in ('hadir', 'izin', 'sakit', 'alfa')) not null default 'alfa', "notes" text, "created_at" datetime, "updated_at" datetime, foreign key("schedule_id") references "schedules"("id") on delete cascade, foreign key("student_id") references "students"("id") on delete cascade);


DROP TABLE IF EXISTS "cache";
CREATE TABLE "cache" ("key" varchar not null, "value" text not null, "expiration" integer not null, primary key ("key"));


DROP TABLE IF EXISTS "cache_locks";
CREATE TABLE "cache_locks" ("key" varchar not null, "owner" varchar not null, "expiration" integer not null, primary key ("key"));


DROP TABLE IF EXISTS "classrooms";
CREATE TABLE "classrooms" ("id" integer primary key autoincrement not null, "name" varchar not null, "grade" integer not null, "academic_year" varchar not null default '2026/2027', "created_at" datetime, "updated_at" datetime);


DROP TABLE IF EXISTS "failed_jobs";
CREATE TABLE "failed_jobs" ("id" integer primary key autoincrement not null, "uuid" varchar not null, "connection" varchar not null, "queue" varchar not null, "payload" text not null, "exception" text not null, "failed_at" datetime not null default CURRENT_TIMESTAMP);


DROP TABLE IF EXISTS "gallery_albums";
CREATE TABLE "gallery_albums" ("id" integer primary key autoincrement not null, "created_at" datetime, "updated_at" datetime, "title" varchar, "slug" varchar, "description" text, "cover_path" varchar, "is_public" tinyint(1) not null default '0');


DROP TABLE IF EXISTS "gallery_items";
CREATE TABLE "gallery_items" ("id" integer primary key autoincrement not null, "created_at" datetime, "updated_at" datetime, "album_id" integer, "image_path" varchar, "caption" varchar, "order" integer not null default '0', foreign key("album_id") references "gallery_albums"("id") on delete cascade);


DROP TABLE IF EXISTS "job_batches";
CREATE TABLE "job_batches" ("id" varchar not null, "name" varchar not null, "total_jobs" integer not null, "pending_jobs" integer not null, "failed_jobs" integer not null, "failed_job_ids" text not null, "options" text, "cancelled_at" integer, "created_at" integer not null, "finished_at" integer, primary key ("id"));


DROP TABLE IF EXISTS "jobs";
CREATE TABLE "jobs" ("id" integer primary key autoincrement not null, "queue" varchar not null, "payload" text not null, "attempts" integer not null, "reserved_at" integer, "available_at" integer not null, "created_at" integer not null);


DROP TABLE IF EXISTS "landing_sections";
CREATE TABLE "landing_sections" ("id" integer primary key autoincrement not null, "key" varchar not null, "title" varchar not null, "body" text, "image_path" varchar, "order" integer not null default '0', "is_visible" tinyint(1) not null default '1', "created_at" datetime, "updated_at" datetime);


DROP TABLE IF EXISTS "news";
CREATE TABLE "news" ("id" integer primary key autoincrement not null, "created_at" datetime, "updated_at" datetime, "title" varchar, "slug" varchar, "excerpt" text, "body" text, "image_path" varchar, "category_id" integer, "status" varchar not null default 'draft', "published_at" datetime, foreign key("category_id") references "news_categories"("id") on delete set null);


DROP TABLE IF EXISTS "news_categories";
CREATE TABLE "news_categories" ("id" integer primary key autoincrement not null, "created_at" datetime, "updated_at" datetime, "name" varchar, "slug" varchar, "description" text);


DROP TABLE IF EXISTS "p_p_d_b_registrations";
CREATE TABLE "p_p_d_b_registrations" ("id" integer primary key autoincrement not null, "created_at" datetime, "updated_at" datetime, "wave_id" integer, "name" varchar, "nisn" varchar, "phone" varchar, "email" varchar, "address" text, "status" varchar not null default 'pending', "notes" text, foreign key("wave_id") references "p_p_d_b_waves"("id") on delete cascade);


DROP TABLE IF EXISTS "p_p_d_b_waves";
CREATE TABLE "p_p_d_b_waves" ("id" integer primary key autoincrement not null, "created_at" datetime, "updated_at" datetime, "name" varchar, "slug" varchar, "description" text, "banner_path" varchar, "start_date" date, "end_date" date, "status" varchar not null default 'buka', "is_public" tinyint(1) not null default '1');


DROP TABLE IF EXISTS "password_reset_tokens";
CREATE TABLE "password_reset_tokens" ("email" varchar not null, "token" varchar not null, "created_at" datetime, primary key ("email"));


DROP TABLE IF EXISTS "personal_access_tokens";
CREATE TABLE "personal_access_tokens" ("id" integer primary key autoincrement not null, "tokenable_type" varchar not null, "tokenable_id" integer not null, "name" text not null, "token" varchar not null, "abilities" text, "last_used_at" datetime, "expires_at" datetime, "created_at" datetime, "updated_at" datetime);


DROP TABLE IF EXISTS "schedules";
CREATE TABLE "schedules" ("id" integer primary key autoincrement not null, "classroom_id" integer not null, "subject_id" integer not null, "teacher_id" integer, "day_of_week" varchar check ("day_of_week" in ('mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun')) not null, "start_time" time not null, "end_time" time not null, "academic_year" integer, "created_at" datetime, "updated_at" datetime, foreign key("classroom_id") references "classrooms"("id") on delete cascade, foreign key("subject_id") references "subjects"("id") on delete cascade, foreign key("teacher_id") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "school_principals";
CREATE TABLE "school_principals" ("id" integer primary key autoincrement not null, "name" varchar not null, "title" varchar, "photo_path" varchar, "signature_path" varchar, "term_start" date, "is_current" tinyint(1) not null default '1', "created_at" datetime, "updated_at" datetime);


DROP TABLE IF EXISTS "scores";
CREATE TABLE "scores" ("id" integer primary key autoincrement not null, "student_id" integer not null, "subject_id" integer not null, "classroom_id" integer not null, "teacher_id" integer, "semester" varchar not null default 'ganjil', "academic_year" varchar, "value" numeric not null, "created_at" datetime, "updated_at" datetime, foreign key("student_id") references "students"("id") on delete cascade, foreign key("subject_id") references "subjects"("id") on delete cascade, foreign key("classroom_id") references "classrooms"("id") on delete cascade, foreign key("teacher_id") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "sessions";
CREATE TABLE "sessions" ("id" varchar not null, "user_id" integer, "ip_address" varchar, "user_agent" text, "payload" text not null, "last_activity" integer not null, primary key ("id"));


DROP TABLE IF EXISTS "site_settings";
CREATE TABLE "site_settings" ("id" integer primary key autoincrement not null, "app_name" varchar not null default 'SMA Madani Al-Aziziyah', "address" varchar, "phone" varchar, "logo_path" varchar, "created_at" datetime, "updated_at" datetime, "nspp" varchar, "npsn" varchar, "jenjang" varchar not null default 'SMA Sains & Tahfidz Berasrama Penuh', "akreditasi" varchar not null default 'A+ Unggul (BAN-SM 2024)', "milad" varchar not null default '2012 M / 1433 H', "tagline" varchar not null default 'Membentuk Generasi Unggul Berkarakter Madani & Berwawasan Global', "vision" text, "hero_image" varchar, "favicon" varchar, "kop_surat" varchar, "email" varchar, "map_lat" varchar, "map_lng" varchar, "instagram" varchar, "youtube" varchar, "tiktok" varchar, "facebook" varchar, "social_enabled" text, "wa_helpdesk" varchar, "pstn" varchar);


DROP TABLE IF EXISTS "students";
CREATE TABLE "students" ("id" integer primary key autoincrement not null, "nis" varchar not null, "name" varchar not null, "classroom_id" integer not null, "parent_id" integer, "status" varchar check ("status" in ('aktif', 'nonaktif', 'lulus')) not null default 'aktif', "created_at" datetime, "updated_at" datetime, "nisn" varchar, "gender" varchar check ("gender" in ('L', 'P')), foreign key("classroom_id") references "classrooms"("id") on delete restrict on update cascade, foreign key("parent_id") references "users"("id") on delete set null);


DROP TABLE IF EXISTS "subjects";
CREATE TABLE "subjects" ("id" integer primary key autoincrement not null, "name" varchar not null, "code" varchar not null, "created_at" datetime, "updated_at" datetime);


DROP TABLE IF EXISTS "teacher_attendances";
CREATE TABLE "teacher_attendances" ("id" integer primary key autoincrement not null, "teacher_id" integer not null, "date" date not null, "check_in" time, "check_out" time, "status" varchar check ("status" in ('hadir', 'izin', 'sakit', 'alfa')) not null default 'alfa', "notes" text, "created_at" datetime, "updated_at" datetime, foreign key("teacher_id") references "users"("id") on delete cascade);


DROP TABLE IF EXISTS "teacher_subjects";
CREATE TABLE "teacher_subjects" ("id" integer primary key autoincrement not null, "teacher_id" integer not null, "subject_id" integer not null, "classroom_id" integer not null, "academic_year" varchar not null default '2026/2027', "created_at" datetime, "updated_at" datetime, foreign key("teacher_id") references "users"("id") on delete cascade, foreign key("subject_id") references "subjects"("id") on delete cascade, foreign key("classroom_id") references "classrooms"("id") on delete cascade);


DROP TABLE IF EXISTS "users";
CREATE TABLE "users" ("id" integer primary key autoincrement not null, "name" varchar not null, "email" varchar not null, "email_verified_at" datetime, "password" varchar not null, "remember_token" varchar, "created_at" datetime, "updated_at" datetime, "role" varchar check ("role" in ('admin', 'bendahara', 'guru', 'wali_murid')) not null default 'wali_murid', "phone" varchar, "is_active" tinyint(1) not null default '1', "is_protected" tinyint(1) not null default '0');

INSERT INTO "users" ("id","name","email","email_verified_at","password","remember_token","created_at","updated_at","role","phone","is_active","is_protected") VALUES ('1','Elody Douglas Jr.','graham.barney@example.org','2026-09-30 08:23:21','$2y$04$75MZR5ApUvxo1yvE8GkbA.YaBWzpWIckYhwM3h9I9YbNF1GvqiuEa','xDujlYrW1y','2026-09-30 08:23:21','2026-09-30 08:23:21','admin','+1 (256) 355-0349','1','0');

